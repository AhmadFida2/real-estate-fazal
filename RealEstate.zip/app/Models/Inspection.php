<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inspection extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'contact_inspector_info' => 'json',
        'servicer_loan_info' => 'json',
        'management_onsite_info' => 'json',
        'comments' => 'json',
        'profile_occupancy_info' => 'json',
        'capital_expenditures' => 'json',
        'operation_maintenance_plans' => 'json',
        'neighborhood_site_data' => 'json',
        'physical_condition' => 'json',
        'images' => 'json',
    ];
}
