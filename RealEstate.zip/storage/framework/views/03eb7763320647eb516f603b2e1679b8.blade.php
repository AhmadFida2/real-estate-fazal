    <x-filament::button
        type="submit"
        size="sm"
    >
        Submit
    </x-filament::button>